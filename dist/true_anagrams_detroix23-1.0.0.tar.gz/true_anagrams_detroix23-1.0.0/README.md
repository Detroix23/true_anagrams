# True Anagram

Find anagrams, and find if they exist in the dictionnary.

## Usage
Run using a Virtual Environement.
With no arguments, the scripts launches an interactive input screen.
    - Enter words, and it will find existing anagrams.

Enter `--help` as an argument, to get help about other commands.
 